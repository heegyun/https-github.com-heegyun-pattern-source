package my.srp.before;

import java.util.ArrayList;

/*
 *  월세 관리  프로그램
 *  
 */
public class RentalManager {
	
	private RentalBook rentalbook;
	
	//생성자...
	public RentalManager(RentalBook rentalbook){
		this.rentalbook = rentalbook;
	}

	// setter, getter 메소드
	public RentalBook getRentalbook() {
		return rentalbook;
	}

	public void setRentalbook(RentalBook rentalbook) {
		this.rentalbook = rentalbook;
	}
	
	// 특정 집의 총 임대비용 계산 메소드
	public double claculateRentalValue(String houseName){
		double sum =0;
		
		Resident[] residents = rentalbook.getAllResidents();
		
		for(int i=0;i<residents.length;i++){
			if(residents[i].getHouseName().equals(houseName)){
				sum+=residents[i].calculateRentalValue();
				
			}
		}
		return sum;
	}
	
	//  특정 집안의 특정 방의 임대 비용을 계산하는 메소드
	public double calculateRentalValue(String houseName, String roomName){
		double sum=0;
		Resident[] residents = rentalbook.getAllResidents();

		for (int i = 0; i < residents.length; i++) {
			if (residents[i].getHouseName().equals(houseName) && residents[i].getRoomName().equals(roomName)) {
				sum += residents[i].calculateRentalValue();
				
			}
		}
		return sum;
	}
	
	// 특정 집의 거주자 수를 계산하는 메소드
	public int countResidents(String houseName){
		int count=0;
		Resident[] residents = rentalbook.getAllResidents();

		for (int i = 0; i < residents.length; i++) {
			if (residents[i].getHouseName().equals(houseName)) {
				count++;
				
			}
			
		}
		return count;
	}

	// 특정 집안의 특정 방의 거주자 수를 계산하는 메소드
	public int countResidents(String houseName, String roomName) {
		int count=0;
		Resident[] residents = rentalbook.getAllResidents();

		for (int i = 0; i < residents.length; i++) {
			if (residents[i].getHouseName().equals(houseName) && residents[i].getRoomName().equals(roomName)) {
				count++;
			}
			
		}
		return count;
	}
	
	// 특정 집안의 특정 방의 거주자들을 반환 하는 메소드
		public Resident[] getRoomResidents(String houseName, String roomName) {
			ArrayList roomResidents = new ArrayList();
			Resident[] allResidents = rentalbook.getAllResidents();

			for (int i = 0; i < allResidents.length; i++) {
				if (allResidents[i].getHouseName().equals(houseName) && allResidents[i].getRoomName().equals(roomName)) {
					roomResidents.add(allResidents[i]);
				}
				
			}
			return (Resident[]) roomResidents.toArray(new Resident[0]);
		}

	
	
	
	
}
