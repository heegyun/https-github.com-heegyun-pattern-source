package my.srp.before;

public class RentalValueCalculator {

	public static void main(String[] args) {
		
		
		RentalBook rentalBook = new RentalBook();
		rentalBook.addResident(new Resident("삼국집","100","Adult","유비"));
		rentalBook.addResident(new Resident("삼국집","100","Adult","관우"));
		rentalBook.addResident(new Resident("삼국집","100","Adult","장비"));
		rentalBook.addResident(new Resident("삼국집","100","Children","아두"));
		rentalBook.addResident(new Resident("삼국집","101","Adult","조조"));
		rentalBook.addResident(new Resident("삼국집","102","Adult","손권"));
		rentalBook.addResident(new Resident("삼국집","101","Adult","송강"));
		rentalBook.addResident(new Resident("삼국집","101","Adult","노지심"));
		rentalBook.addResident(new Resident("삼국집","101","Adult","무송"));
		
		RentalManager manager = new RentalManager(rentalBook);
		
		printRentalStatus(manager,"삼국집");
		
		
	}//main()---------------------

	 static void printRentalStatus(RentalManager manager, String houseName) {
		
		System.out.println("***********************************");
		System.out.println("이 집의 이름: " + houseName);
		System.out.println("이 집에 살고 있는 거주자의 수: " + manager.countResidents(houseName));
		System.out.println("이 집의 총 임대비용: " + manager.claculateRentalValue(houseName));
		System.out.println("************************************");
	}
	
	static void printRentalStatus(RentalManager manager, String houseName, String roomName){
		System.out.println("***********************************");
		System.out.println("이 집의 이름: " + houseName);
		System.out.println("이 방의 이름: " + houseName);
		System.out.println("이 집에 살고 있는 거주자의 수: " + manager.countResidents(houseName,roomName));
		System.out.println("이 집의 총 임대비용: " + manager.calculateRentalValue(houseName,roomName));
		System.out.println("************************************");
		Resident[] roomResidents = manager.getRoomResidents(houseName, roomName);
		for(int i=0;i<roomResidents.length;i++){
			System.out.println("거주자 이름: " + roomResidents[i].getName()+", " + "임대비: " + roomResidents);
			System.out.println("*****************************************");
		}
	}
	

}
