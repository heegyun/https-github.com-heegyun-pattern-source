package my.srp.before;

/*
 *  거주자 클래스
 */
public class Resident {
	private String houseName; // 거주자 집 이름
	private String roomName; // 거주자 방 이름
	private String name;// 거주자 이름
	private String type; // adult, children...
	
	
	public Resident(String houseName, String roomName, String name, String type){
		this.houseName = houseName;
		this.roomName = roomName;
		this.name = name;
		this.type= type;
	}

	public double calculateRentalValue(){
		double rentalValue=0;
		if(type.equals("Adult")){
			rentalValue=10;
		}else if(type.equals("Children")){
			rentalValue=2;
		}
		return rentalValue;
	}

	public String getHouseName() {
		return houseName;
	}

	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
