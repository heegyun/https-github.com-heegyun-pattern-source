package my.srp.before;

import java.util.ArrayList;

/*
 *  장부 클래스
 */
public class RentalBook {

	private ArrayList residents;
	
	
	public RentalBook(){
		residents = new ArrayList();
	}


	public Resident[] getAllResidents(){
		return (Resident[]) residents.toArray(new Resident[0]);
		
	}
	
	public void addResident(Resident res){
		residents.add(res);
	}
	public void removeResident(Resident res){
		residents.remove(res);
	}
	
	
	
	
}
